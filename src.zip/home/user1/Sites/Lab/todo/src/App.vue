<template>
  <div id="app">   

    <body id="page-top">
    <background></background>
    <router-view></router-view>
    <foot></foot>
    </body>

  </div>
</template>


<script>
import Background from './components/Background.vue'
import Foot from './components/Footer.vue'

export default {
  name: 'app',
  components: {
    Background,
    Foot
  }
}
</script>


