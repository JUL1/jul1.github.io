
<template>
<div>

<b-navbar toggleable="md" type="dark" fixed="top" class="mx-0 px-0">

  <b-navbar-brand id="page-top" v-scrollTo.easeOutQuart="'page-top'">CMDT</b-navbar-brand>

  <b-nav-toggle target="nav_collapse" position="right">Menu</b-nav-toggle>

  <b-collapse is-nav id="nav_collapse">

    <!-- Right aligned nav items -->
    <b-nav is-nav-bar class="ml-auto" id=navMenu>

    <b-nav-item v-scrollTo.easeOutQuart="'about'">Download</b-nav-item>
    <b-nav-item v-scrollTo.easeOutQuart="'controls'">Controls</b-nav-item>
    <b-nav-item v-scrollTo.easeOutQuart="'screenshots'">Screenshots</b-nav-item>
    <b-nav-item v-scrollTo.easeOutQuart="'contact'">Contact</b-nav-item>


    </b-nav>

  </b-collapse>
</b-navbar>

<b-container class="container-full" id="topSection">
          <b-col>

                <h1>
                    <div id="playBtn"><a href="games/CommandoThug-master/index.html">&#9654;</a></div>
                </h1>
                
                <div>
                    <div id="clock">--- : --- : ---{{clock}}</div>
                </div>
                 <div class="circleBtn"><a v-scrollTo.easeOutQuart="'about'"><icon scale="3.8" name="chevron-down"></icon></a></div>
          
          </b-col>
</b-container>



<b-container class="container-full section" id="about" offset="75">
          <b-col>
                    <h2 class="section-heading">WELCOME</h2>
                    <hr class="primary">

                  <p>
                    <a href="https://phaser.io/news/2015/09/commando-thug" target="_blank">CommandoThug</a> is a canvas based action game I made during the years 2014/2015
                    </br></br>

                    It's based on the 2D game framework called "Phaser" which can be found <a href="https://phaser.io/" target="_blank">here</a>
                    </br></br></br>
                    
                    This game is now licensed under <a href="https://www.gnu.org/licenses/quick-guide-gplv3.en.html" target="_blank">GPL v3</a>
                    </br></br></br>
                    <div class="noSelect" id=downloadBtns>

                    <span id="licenseLogo"><a href="https://github.com/JUL1/CommandoThug/archive/master.zip"><img width="256" alt="GPLv3 Logo" src="../assets/img/GPLv3_Logo.svg"/></a></span>


                  <span id="downloadBtn"><a href="https://github.com/JUL1/CommandoThug/archive/master.zip"> <icon name="download" id="download" scale="3.3"></icon> Download</a></span> 
                  </p>

                 </div>
                 <div class="circleBtn"><a v-scrollTo.easeOutQuart="'controls'"><icon scale="3.8" name="chevron-down"></icon></a></div>
          
          </b-col>
</b-container>




<b-container class="container-full section" id="controls" offset="75">
          <b-col>


                    <h2 class="section-heading">CONTROLS</h2>
                    <hr class="primary">



        <div class="container">
            <div class="row">


                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <span class="noSelect"><icon scale="5" rotation="90" name="mobile" id="mobileIcon"></icon>
                        </br></br></span>
                        <h3>MOBILE</h3>
                        <p>
                        </br>
                        Touch the screen to point where you want to go</br></br>
                        Your soldier moves toward touch inputs</br>
                        </p>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <span class="noSelect"><icon scale="3.7" name="mouse-pointer" id="mousePointerIcon"></icon>
                        </br></br></span>
                        <h3>MOUSE</h3>
                        <p>
                         </br>
                        Use the mouse pointer to move your soldier</br></br>
                        Your soldier will follow the mouse pointer</br>
                        </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <span class="noSelect"><icon scale="4.5" name="keyboard-o" id="keyboardIcon"></icon>
                        </br></br></span>
                        <h3>KEYBOARD</h3>
                        <p>
                        </br>
                        Use keyboard arrows to move your soldier</br></br>
                        UP, DOWN, LEFT, RIGHT</br> to move


                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <span class="noSelect"><icon scale="3.7" name="mouse-pointer" id="mousePointerIcon2"></icon><icon scale="4.5" name="keyboard-o" id="keyboardIcon2"></icon>
                        </br></br></span>
                        <h3>2 Players</h3>
                        <p>
                        </br>
                        Available in the game's options menu</br></br>
                        Player1 with mouse</br> 
                        Player2 with keyboard

                        </p>

                    </div>
                </div>

                <div class="col-lg-12 text-center">

                       <p></br></br> - - -&nbsp;&nbsp;Your soldier shoots automatically at the closest target&nbsp;&nbsp;- - -  </p>
                      
                </div>                
           
              </div>                
            </div>
            <div class="circleBtn"><a v-scrollTo.easeOutQuart="'screenshots'"><icon scale="3.8" name="chevron-down"></icon></a></div>

          </b-col>
</b-container>





<b-container class="container-full section" id="screenshots" offset="75">
          <b-col>

                    <h2 class="section-heading">SCREENSHOTS</h2>
                    <hr class="primary">

                    <div class="noSelect">
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/1.png">
                          <div class="imgOverlay"><span>screenshot 1</br>COMMANDOTHUG</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/2.png">
                          <div class="imgOverlay"><span>screenshot 2</br>COMMANDOTHUG</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/3.png">
                          <div class="imgOverlay"><span>screenshot 3</br>COMMANDOTHUG</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/4.png">
                          <div class="imgOverlay"><span>screenshot 4</br>COMMANDOTHUG</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/5.png">
                          <div class="imgOverlay"><span>screenshot 5</br>COMMANDOTHUG</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/screenshots/6.png">
                          <div class="imgOverlay"><span>screenshot 6</br>COMMANDOTHUG</span></div>
                    </div>
                    </div>             

                        <div class="circleBtn"><a v-scrollTo.easeOutQuart="'contact'"><icon scale="3.8" name="chevron-down"></icon></a></div>

            </b-col>
</b-container>



<b-container class="container-full section" id="contact" offset="75">
      <b-col>

                    <h2 class="section-heading">CONTACT</h2>
                    <hr class="primary">
                    <p>
            
                    Don't forget to check out my <router-link to="/artworks">artworks</router-link></br>
                    You can also visit those <router-link to="/links">sites</router-link></br></br></br>

                    Feel free to contact me by mail for job proposal</br> 
                    Or donate bitcoins at the address below :</br></br>
 

                    </br>


                    </p>

        <div class="container">
            <div class="row">

              <div class="col-lg-2" id="fuckIt"></div>

                <div class="col-lg-5">
               <icon name="bitcoin" scale="3"></icon>
               <p id="donate"></br>DONATE&nbsp;BITCOIN:</br>13cVc2FLV1bdWbdkk1S4qTgVnS6vhDeCNS</p>
              </div>
          
                <div class="col-lg-4">
               <icon name="envelope-o" scale="3" id="mailIcon"></icon>
              <p><div id="contactMail">CONTACT:</br><span id="at" data-user="jul.perso" data-domain="mail.com"></span></div></p>
              </br></br>
          </div> 

      </div>

  </div>
           
    </b-col>
</b-container>


</div>
</template>


<script>
export default {
  name: 'home',
  name: 'Clock',
    data() {
        return {
            clock: null
        }
    },
    created()
    {   
        setInterval(() =>
        {
            
            document.getElementById('clock').innerHTML=new Date();
        }, 1000);
    }

}
</script>

