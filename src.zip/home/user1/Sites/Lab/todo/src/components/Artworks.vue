
<template>
<div>


<b-navbar toggleable="md" type="dark" fixed="top" class="mx-0 px-0">

  <b-navbar-brand id="page-top" ><router-link to="/">CMDT</router-link></b-navbar-brand>


</b-navbar>


<b-container class="container-full section2" id="topSection" offset="75">
          <b-col>

                    <h2 class="section-heading">ARTWORKS</h2>
                    <hr class="primary">

                    <div class="noSelect">



                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork1.jpg">
                          <div class="imgOverlay"><span>Cybersawman</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork2.jpg">
                          <div class="imgOverlay"><span>Robotic Mercenary</br>PHOTOSHOP</span></div>
                    </div>
                    
                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork5.jpg">
                          <div class="imgOverlay"><span>Gatling fat man</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork4.jpg">
                          <div class="imgOverlay"><span>Mutant Flies</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork3.jpg">
                          <div class="imgOverlay"><span>Mutant plant</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork8.jpg">
                          <div class="imgOverlay"><span>Fancy buttons</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork7.jpg">
                          <div class="imgOverlay"><span>MiArmored</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork10.jpg">
                          <div class="imgOverlay"><span>Dodezone</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork9.jpg">
                          <div class="imgOverlay"><span>Dodezone</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork11.gif">
                          <div class="imgOverlay"><span>MiArmored</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer">
                        <img v-img:screenshots src="../assets/img/artworks/artwork6.jpg">
                          <div class="imgOverlay"><span>Lightball</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork12.png">
                          <div class="imgOverlay"><span>Boxer</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork13.jpg">
                          <div class="imgOverlay"><span>Cyclop</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork14.jpg">
                          <div class="imgOverlay"><span>Troll House</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer  noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork15.jpg">
                          <div class="imgOverlay"><span>Carzy Frog</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork16.jpg">
                          <div class="imgOverlay"><span>Characters</br>FLASH</span></div>
                    </div>

                    <div class="imgContainer  noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork18.jpg">
                          <div class="imgOverlay"><span>Conference Room</br>ILLUSTRATOR</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork17.jpg">
                          <div class="imgOverlay"><span>Amazon</br>DRAWING</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork19.jpg">
                          <div class="imgOverlay"><span>Swordman</br>DRAWING</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork20.jpg">
                          <div class="imgOverlay"><span>3D Character</br>PHOTOSHOP</span></div>
                    </div>

                    <div class="imgContainer noScale">
                        <img v-img:screenshots src="../assets/img/artworks/artwork21.jpg">
                          <div class="imgOverlay"><span>Boxer</br>PHOTOSHOP</span></div>
                    </div>






                </div>


        </br>


          </b-col>
</b-container>




</div>
</template>


<script>
export default {
  name: 'artworks',
    created()
    {   
          window.scrollTo(0, 0);
    }

}
</script>

