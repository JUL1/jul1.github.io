<template>


    <footer id="footer">
 
        <div class="circleBtn"><a v-scrollTo.easeOutQuart="'page-top'"><icon scale="4" name="chevron-up"></icon></a></div>

    </footer>
    
</template>
<script>


export default {
  name: 'foot'
}
</script>