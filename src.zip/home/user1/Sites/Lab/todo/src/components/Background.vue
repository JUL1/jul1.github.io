<template>

<div>
    <div id="BKG"></div>
    <div id="scanlines"></div>
</div>

</template>

<script>
export default {
  name: 'background'
}
</script>




