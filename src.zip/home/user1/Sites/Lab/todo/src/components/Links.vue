
<template>
<div>

<b-navbar toggleable="md" type="dark" fixed="top" class="mx-0 px-0">

  <b-navbar-brand id="page-top" to="/">CMDT</b-navbar-brand>


</b-navbar>

<b-container class="container-full section" id="topSection" offset="75">
          <b-col>


        <div class="container">
            <div class="row">


       <div class="col-lg-2  col-md-4  col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">UTILS</h2></br>
          <a href="https://www.google.com" target="_blank">Google</a></br>
          <a href="https://www.duckduckgo.com" target="_blank">DuckDuckGo</a></br>
          <a href="https://ixquick.fr/do/mypage.pl?prf=1357cf6d88289acdfcc994b6d589702a" target="_blank">Ixquick</a></br>
          <a href="http://gibiru.com/" target="_blank">Gibiru</a></br>
          <a href="https://www.bing.com/" target="_blank">Bing</a></br>
          <a href="https://www.tineye.com/" target="_blank">Tineye</a></br>
          <a href="https://postimg.org/" target="_blank">Postimg</a></br>
          <a href="http://imgjar.co/" target="_blank">Imgjar</a></br>
          <a href="https://github.com/" target="_blank">GitHub</a></br>
          <a href="https://www.youtube.com/watch?v=Jjhe6ypF6zc" target="_blank">Youtube</a></br>
          <a href="https://www.bitchute.com/" target="_blank">Bitchute</a></br>
          <a href="https://translate.google.com" target="_blank">Google Translate</a></br>
          <a href="http://www.colorzilla.com/gradient-editor/"target="_blank">CSS Gradients</a></br>
          <a href="https://kiwiirc.com/client" target="_blank">KIWIIRC</a></br>
          <a href="http://10minutemail.com/10MinuteMail/index.html" target="_blank">10MinuteMail</a></br>
          <a href="https://www.gmx.com/" target="_blank">GMX</a></br>
          <a href="https://protonmail.com/" target="_blank">Protonmail</a></br>
          <a href="https://www.javascriptobfuscator.com/" target="_blank">JS Obfuscator</a></br>
          <a href="http://caniuse.com/" target="_blank">CanIUse</a></br>
          <a href="http://anonym.to/" target="_blank">Anonym</a></br>
          <a href="http://www.shodanhq.com/" target="_blank">Shodanhq</a></br>
          <a href="http://www.norse-corp.com/" target="_blank">NorseCorp</a></br>
          <a href="https://www.mailinator.com/" target="_blank">Mailinator</a></br>
          <a href="http://game-icons.net/" target="_blank">Game icons</a></br>
          <a href="https://webtorrent.io/" target="_blank">Webtorrent</a></br>
          <a href="http://www.onstrat.com/osint/" target="_blank">Onstrat</a></br>
          <a href="https://bitly.com/" target="_blank">Bitly</a></br>
          <a href="https://www.minds.com/" target="_blank">Minds</a></br>
          <a href="https://gab.ai/" target="_blank">Gab</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

     <div class="col-lg-2  col-md-4  col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">NEWS</h2></br>
          <a href="http://www.zerohedge.com" target="_blank">Zerohedge</a></br>
          <a href="http://www.drudgereport.com" target="_blank">Drudge Report</a></br>
          <a href="https://www.corbettreport.com" target="_blank">Corbett Report</a></br>
          <a href="http://www.globalresearch.ca/" target="_blank">Global Research</a></br>
          <a href="http://www.telegraph.co.uk/finance/comment/ambroseevans_pritchard/" target="_blank">The Telegraph</a></br>
          <a href="http://thehackernews.com/" target="_blank">TheHackerNews</a></br>
          <a href="http://www.infowars.com/" target="_blank">InfoWars</a></br>
          <a href="http://www.fark.com/" target="_blank">Fark</a></br>
          <a href="http://www.thesmokinggun.com/" target="_blank">TheSmokingGun</a></br>
          <a href="http://www.abovetopsecret.com/" target="_blank">ATS</a></br>
          <a href="http://fr.news.yahoo.com/" target="_blank">YahooNews_FR</a></br>
          <a href="http://news.yahoo.com/us/" target="_blank">YahooNews_US</a></br>
          <a href="http://weeklyworldnews.com/" target="_blank">WeeklyWorldNews</a></br>
          <a  >---</a></br> 
          <a  >---</a></br> 
          <a  >---</a></br>          
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

     <div class="col-lg-2  col-md-4  col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">RADIO</h2></br>
          <a href="http://somafm.com/" target="_blank">Soma FM</a></br>
          <a href="http://www.jazzradio.fr/radio/webradio/electro-swing" target="_blank">Jazz Radio</a></br>
          <a href="http://swissclassic.radio.fr/" target="_blank">Swiss Classic</a></br>
          <a href="http://www.infowars.com/free-audio/" target="_blank">InfoWars</a></br>
          <a href="http://www.radioclassic.fi/" target="_blank">Radioclassic</a></br>
          <a href="http://www.shoutcast.com/radio/Classical" target="_blank">Shoutcast</a></br>
          <a href="http://www.fipradio.fr/player" target="_blank">Fip</a></br>
          <a href="http://radiolibertaire.radio.fr/" target="_blank">Radio Libertaire</a></br>
          <a href="http://www.radiocourtoisie.fr/presentation-de-radio-courtoisie/" target="_blank">Radio Courtoisie</a></br>
          <a href="http://www.franceculture.fr/player" target="_blank">France Culture</a></br>
          <a href="http://www.rfi.fr/contenu/ecouter-rfi-direct-monde" target="_blank">RFI</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

       <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">FORUM</h2></br>
          <a href="http://www.html5gamedevs.com/" target="_blank">html5gamedevs</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

     <div class="col-lg-2  col-md-4  col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">GAMES</h2></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

     <div class="col-lg-2  col-md-4  col-sm-6">
          <div class="links"></br>
          <h2 class="section-heading">MISC</h2></br>
          <a href="http://www.mysqltutorial.org/" target="_blank">mysqltutorial</a></br>
          <a href="http://www.w3schools.com/sql/default.asp" target="_blank">w3schools</a></br>
          <a href="http://www.phptherightway.com/" target="_blank">phptherightway</a></br>
          <a href="http://www.ibm.com/developerworks/" target="_blank">IBM</a></br>
          <a href="http://symfony.com/doc/2.5/index.html" target="_blank">symfony</a></br>
          <a href="http://www.learn-angular.org/" target="_blank">learn-angular</a></br>
          <a href="http://www.angular2.com/" target="_blank">angular2</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          <a  >---</a></br>
          </div>
     </div>

     </div>
</div>

    </br></br>

     </br></br>

          </b-col>
</b-container>


</div>
</template>


<script>
export default {
  name: 'links',
    created()
    {   
          window.scrollTo(0, 0);
    }

}
</script>

