import Vue from 'vue'
import Router from 'vue-router'

import Home from '@/components/Home'
import Links from '@/components/Links.vue'
import Artworks from '@/components/Artworks.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {path: '/', name: 'home',component: Home},
    {path: '/Links', name: 'links',component: Links},
    {path: '/Artworks', name: 'artworks',component: Artworks}

  ]
})


