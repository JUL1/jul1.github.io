import Vue from 'vue'

Vue.directive('scrollTo', {
    inserted : function(el, binding) {
        var easing = easings.linear;
        let target = document.querySelector(`#${binding.value}`);
        let offset = parseInt(target.getAttribute('offset')) || 0;
        let duration = parseInt(target.getAttribute('duration')) || 1000;
        let start = null;
        let y = target.getBoundingClientRect().top;
        var from = window.pageYOffset;
        var running = false;

        for(let modifier in binding.modifiers)
            if(typeof easings[modifier] != 'undefined')
                easing = easings[modifier];

        let scroll = () => {
            if(running) {
                let now = Date.now();
                let time = Math.min(1, (now - start) / duration);
                let ease = easing(time);

                window.scrollTo(0, (ease * (y - from)) + from);

                if(time < 1)
                    requestAnimationFrame(scroll);
                else
                    running = false;
            }
        };

        window.addEventListener('mousewheel', e => running = false);
        

        if(target) {
            el.addEventListener('click', event => {
                running = true;
                from = window.pageYOffset;
                y = target.getBoundingClientRect().top + from + offset;
                start = Date.now();
                requestAnimationFrame(scroll);
            })
        }
    }
});

const easings = {
    linear         : t => t,
    easeInQuad     : t => t * t,
    easeOutQuad    : t => t * (2 - t),
    easeInOutQuad  : t => t < .5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
    easeInCubic    : t => t * t * t,
    easeOutCubic   : t => (--t) * t * t + 1,
    easeInOutCubic : t => t < .5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
    easeInQuart    : t => t * t * t * t,
    easeOutQuart   : t => 1 - (--t) * t * t * t,
    easeInOutQuart : t => t < .5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t,
    easeInQuint    : t => t * t * t * t * t,
    easeOutQuint   : t => 1 +(--t) * t * t * t * t,
    easeInOutQuint : t => t < .5 ? 16 * t * t * t * t * t : 1 + 16 * (--t) * t * t * t * t,
    easeOutCirc    : t => Math.sqrt(1 - (--t * t))
};