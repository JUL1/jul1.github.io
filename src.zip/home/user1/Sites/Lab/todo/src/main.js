// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.

import Vue from 'vue'
import App from './App'
import router from './router'
import BootstrapVue from 'bootstrap-vue'


import VueImg from 'v-img';
import Icon from 'vue-awesome/components/Icon'

//const vueImgConfig = {
  //altAsTitle: false,
//}

Vue.use(VueImg);
Vue.component('icon', Icon);
Vue.use(BootstrapVue);


import scrollTo from './directives/scrollTo.js'

import 'bootstrap/dist/css/bootstrap.min.css'

import 'vue-awesome/icons/bars'
import 'vue-awesome/icons/chevron-down'
import 'vue-awesome/icons/download'
import 'vue-awesome/icons/mobile'
import 'vue-awesome/icons/mouse-pointer'
import 'vue-awesome/icons/keyboard-o'
import 'vue-awesome/icons/bitcoin'
import 'vue-awesome/icons/envelope-o'
import 'vue-awesome/icons/chevron-up'
//import 'bootstrap-vue/dist/bootstrap-vue.css'
//import "./assets/vendor/font-awesome/css/font-awesome.min.css"
import "./assets/css/main.css"



//Vue.config.productionTip = process.env.NODE_ENV == 'development'

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
